# suricata4everyone
An adaptation of the Suricata IDS engine to be installed and used by everyone in their local environment without needing an external resource to understand the alerts logged 
